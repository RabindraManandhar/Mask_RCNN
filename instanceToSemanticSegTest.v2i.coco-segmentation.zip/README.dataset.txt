# instanceToSemanticSegTest > 2024-07-03 2:00pm
https://universe.roboflow.com/mtsu-4rtyu/instancetosemanticsegtest

Provided by a Roboflow user
License: CC BY 4.0

